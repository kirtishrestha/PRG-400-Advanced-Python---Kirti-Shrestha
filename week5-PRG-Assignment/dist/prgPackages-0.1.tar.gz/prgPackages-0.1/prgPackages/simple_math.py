def add(a, b):
    """Returns the sum of two number"""
    return a + b

def subtract(a, b):
    """Returns the difference of two number"""
    return a - b
